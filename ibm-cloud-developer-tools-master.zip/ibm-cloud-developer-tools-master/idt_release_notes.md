
## v1.1.0       Dec 13, 2017
- Integrate DevOps (CF or Kube) during app creation
- Use Docker Compose to Develop a Multi-Container Application
- Launch a Deployed Web Application with View
- Access Local Containers with Shell
- Improved Create Interaction
- Usability Improvements
- and bug fixes

You can read about this new release here:  https://www.ibm.com/blogs/bluemix/2017/12/whats-included-ibm-cloud-developer-tools-cli-version-1-1-0/

## v1.0.8      Oct 26, 2017
- modifies the `bx dev console` command for the new location of projects due to the app-services changes to the Public Cloud console.

